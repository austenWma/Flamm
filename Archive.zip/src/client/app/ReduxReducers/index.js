import { combineReducers } from 'redux';

const combinedReducers = combineReducers({
})

export default combinedReducers;