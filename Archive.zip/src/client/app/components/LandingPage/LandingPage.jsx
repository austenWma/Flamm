import React, {Component} from 'react'
import {render} from 'react-dom'
import {Redirect, Link} from 'react-router-dom'

class LandingPage extends Component {
  constructor (props) {
    super(props)
    this.state = {
        
      };
  }

  render() {
    return (
      <div>
        Hello World
      </div>
    )
  }
}

export default LandingPage;